section .text
    global _start
_start:
    mov eax, 0x1337
    cmp eax, 0x1337
    je success
    ; FLAG{cr4ckm3_1337}