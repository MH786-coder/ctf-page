#include <stdio.h>
void win() { printf("FLAG{buff3r_0v3rfl0w_v1ct1m}"); }
void main() { char buf[16]; gets(buf); }